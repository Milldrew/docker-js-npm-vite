This repo contains a nestjs server an angular SPA and playwright tests

./run_tests_docker.sh # Runs everything, you should run it from the root of the project

The nestjs server is running on port 3000 

And the playwright test report is served to 9323

By clicking on the test names in the playwright test report you will see the detailed information and screen shots if they take screenshots.
